/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackathon2019;

import static hackathon2019.MenuFXMLDocumentController.key;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author tenzintashi
 */
public class GraphFXMLController implements Initializable {

    @FXML
    private Label lblItemName;
    @FXML
    private Button btnBack;
    @FXML
    private Button btnNearMe;
    @FXML
    private Button btnExit;
    @FXML
    private LineChart<String, Number> graphChat;
    @FXML
    private WebView webView;
    @FXML
    private WebEngine engine;

    public void btnDisplayChart() throws FileNotFoundException, IOException {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
         
        series.getData().add(new XYChart.Data<>("Jan", 2.16));
        series.getData().add(new XYChart.Data<>("Feb", 2.30));
        series.getData().add(new XYChart.Data<>("Mar", 3.2));
        series.getData().add(new XYChart.Data<>("Apr", 2.76));
        series.getData().add(new XYChart.Data<>("May", 2.63));
        series.getData().add(new XYChart.Data<>("Jun", 4.57));
        series.getData().add(new XYChart.Data<>("Jul", 6.97));
        series.getData().add(new XYChart.Data<>("Aug", 2.62));
        series.getData().add(new XYChart.Data<>("Sep", 4.53));
        series.getData().add(new XYChart.Data<>("Oct", 4.56));
        series.getData().add(new XYChart.Data<>("Nov", 3.65));
        series.getData().add(new XYChart.Data<>("Dec", 2.89));
        graphChat.getData().add(series);
                
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//         lblItemName.setText(key);
//        
//        try {
//            btnDisplayChart();
//        } catch (IOException ex) {
//            Logger.getLogger(GraphFXMLController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        engine = webView.getEngine();
        

    }    
     @FXML
    private void btnBackWindow(javafx.event.ActionEvent event) throws IOException {

        Parent newparent = FXMLLoader.load(getClass().getResource("menuFXMLDocument.fxml"));
        Scene newscene = new Scene(newparent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(newscene);
        window.show();

    }
    
    @FXML
    private void btnExit() {
        System.exit(0);
    }

//    private void btnNear(){
//        engine.load("https://www.google.com/");
//    }
    
}
